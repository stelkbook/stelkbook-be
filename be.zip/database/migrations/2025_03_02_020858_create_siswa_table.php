<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('siswas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->string('username')->unique();
            $table->string('email')->unique();
            $table->string('password');
            $table->string('nis')->unique();
            $table->enum('gender', ['Laki-Laki', 'Perempuan']);
            $table->enum('sekolah', ['SD', 'SMP', 'SMK']);
            $table->enum('kelas', [
                'I', 'II', 'III', 'IV', 'V', 'VI', // SD
                'VII', 'VIII', 'IX', // SMP
                'X', 'XI', 'XII' // SMK
            ]);
            $table->string('avatar')->nullable();
            $table->timestamps();
        });
        
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('siswas');
    }
};
